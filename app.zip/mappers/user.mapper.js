module.exports = (data) => ({
  email: data.email,
  rank: data.rank,
  name: data.name,
  createdAt: data.createdat,
  updatedAt: data.updatedat,
});
